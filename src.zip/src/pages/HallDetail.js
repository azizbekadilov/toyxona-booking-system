import { useState } from "react";
import CalendarView from "../components/CalendarView";
import BookingForm from "../components/BookingForm";

function HallDetail() {

  const [selectedDate, setSelectedDate] = useState("");

  const hall = {
    name: "Grand Saroy",
    district: "Chilonzor",
    capacity: 300,
    price: 100000,
    phone: "+998901234567"
  };

  return (

    <div className="max-w-6xl mx-auto p-6">

      <div className="bg-white shadow-lg rounded-lg overflow-hidden">

        <img
          src="https://picsum.photos/1200/400"
          alt="hall"
          className="w-full h-64 object-cover"
        />

        <div className="p-6">

          <h1 className="text-3xl font-bold mb-4">
            {hall.name}
          </h1>

          <div className="grid grid-cols-2 gap-4 mb-6">

            <p className="bg-gray-100 p-3 rounded">
              <strong>Rayon:</strong> {hall.district}
            </p>

            <p className="bg-gray-100 p-3 rounded">
              <strong>Sig‘imi:</strong> {hall.capacity}
            </p>

            <p className="bg-gray-100 p-3 rounded">
              <strong>Narxi:</strong> {hall.price} so'm
            </p>

            <p className="bg-gray-100 p-3 rounded">
              <strong>Telefon:</strong> {hall.phone}
            </p>

          </div>

          <h2 className="text-2xl font-semibold mb-4">
            Bo'sh kunlar
          </h2>

          <CalendarView setSelectedDate={setSelectedDate} />

          <div className="mt-8">

            <BookingForm selectedDate={selectedDate} />

          </div>

        </div>

      </div>

    </div>

  );
}

export default HallDetail;