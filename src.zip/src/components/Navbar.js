import { Link } from "react-router-dom";

function Navbar() {
  return (

    <div className="bg-blue-600 text-white p-4">

      <div className="max-w-6xl mx-auto flex justify-between">

        <h1 className="text-xl font-bold">
          Toyxona Booking
        </h1>

        <div className="space-x-4">

          <Link to="/" className="hover:underline">
            Home
          </Link>

          <Link to="/admin" className="hover:underline">
            Admin
          </Link>

          <Link to="/owner" className="hover:underline">
            Owner
          </Link>

        </div>

      </div>

    </div>

  );
}

export default Navbar;